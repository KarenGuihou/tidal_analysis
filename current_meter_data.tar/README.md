The original current meter data are published under the terms of the NERC Open Data Licence:
http://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/

